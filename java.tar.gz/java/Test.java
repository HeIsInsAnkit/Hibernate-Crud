
import com.entity.Organisation;
import org.hibernate.HibernateException;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.boot.registry.StandardServiceRegistry;
import org.hibernate.boot.registry.StandardServiceRegistryBuilder;
import org.hibernate.cfg.Configuration;
import com.entitiees.Employee;
import org.hibernate.query.Query;
import java.util.Iterator;
import java.util.List;
import java.util.Scanner;

class Test {


    private static StandardServiceRegistry ssr;
    private static SessionFactory sf;
    private static Session ss;

    public void UpdateEmployeeRecord() {
        ss = sf.openSession();
        try {
            ss.beginTransaction();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter the ID");
            Long id = sc.nextLong();
            System.out.println("Update your name");
            String name = sc.next();
            System.out.println("Update your salary");
            int sal = sc.nextInt();


            Query query = ss.createQuery("from Employee where id =" + id);
            Employee emp = (Employee) query.uniqueResult();
            emp.SetSal(sal);
            emp.SetName(name);
            ss.update(emp);
            ss.getTransaction().commit();
            System.out.println("Record is updated");
        } catch (HibernateException he) {
            he.printStackTrace();
        } finally {
            ss.close();
        }
    }

    public void RemoveEmployeeRecord() {
        ss = sf.openSession();
        try {
            ss.beginTransaction();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter Record ID");
            Long id = sc.nextLong();

            Query query = ss.createQuery("from Employee where id =" + id);
            Employee emp = (Employee) query.uniqueResult();
            ss.delete(emp);
            ss.getTransaction().commit();
            System.out.println("Removed Record successfully");
        } catch (HibernateException he) {
            he.printStackTrace();
        } finally {
            ss.close();
        }
    }

    public void DisplayEmployeeRecords(Long id) {
        ss = sf.openSession();
        try {

            ss.beginTransaction();
            List<Employee> e1 = ss.createQuery("from Employee where  organisation_oid =" +id).getResultList();

            for (Iterator iterator = e1.iterator(); iterator.hasNext(); ) {
                Employee employee1 = (Employee) iterator.next();
                System.out.println(employee1.getname() + "  "
                        + employee1.getsal()
                        + "   " + employee1.getId());
            }
            ss.getTransaction().commit();

        } catch (HibernateException e) {

            System.out.println(e);

        } finally {

            ss.close();

        }
    }

    public void SaveEmployeeRecords(Long id) {
        ss = sf.openSession();

        try {
            String want;
            Scanner sc = new Scanner(System.in);

            do {
                Organisation org =new Organisation();
                Employee emp=new Employee();
                org.SetId(id);
                emp.setOrganisation(org);



                System.out.println("Enter your name");
                String name = sc.next();
                System.out.println("Enter your salary ");
                int sal = sc.nextInt();
                System.out.println("want you add more records");
                want = sc.next();
                ss.beginTransaction();




                emp.SetName(name);
                emp.SetSal(sal);

                ss.save(emp);
                ss.getTransaction().commit();
                System.out.println("Record inserted successfully");
            } while (want.equals("y"));

        } catch (HibernateException e) {
            System.out.println(e);
        } finally {
            ss.close();
        }
    }


    public static void EmployeeMenu(Long id) {
        Test t2 = new Test();

        Configuration configuration = new Configuration();
        ssr = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        configuration.addAnnotatedClass(Organisation.class).addAnnotatedClass(Employee.class);

        sf = configuration.buildSessionFactory(ssr);

        try {
            int Input;
            do {
                Scanner sc = new Scanner(System.in);
                System.out.println("========Employee Menu========");
                System.out.println("1.Create a record");
                System.out.println("2.Display a record");
                System.out.println("3.Update record");
                System.out.println("4.Remove a record");
                System.out.println("5.Exit ");
                System.out.println("6.Press 0 for back");
                System.out.println("Enter your choice  :");
                Input = sc.nextInt();

                switch (Input) {
                    case 1:
                        t2.SaveEmployeeRecords(id);
                        break;
                    case 2:
                        t2.DisplayEmployeeRecords(id);
                        break;
                    case 3:
                        t2.UpdateEmployeeRecord();
                        break;
                    case 4:
                        t2.RemoveEmployeeRecord();
                        break;
                    case 5:
                        System.exit(1);
                    default:
                        System.out.println("Wrong Input");

                }

            }
            while (Input != 0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void SaveOrganisationRecords() {
        ss = sf.openSession();

        try {

            String want;
            Scanner sc = new Scanner(System.in);

            do {
                Organisation org = new Organisation();

                System.out.println("Enter your name");
                String oname = sc.next();
                System.out.println("Enter your Email ");
                String email = sc.next();
                System.out.println("Enter your Password ");
                String pass = sc.next();

                System.out.println("want you add more records");
                want = sc.next();
                ss.beginTransaction();

                org.SetName(oname);
                org.SetEmail(email);
                org.SetPass(pass);

                ss.save(org);
                ss.getTransaction().commit();
                System.out.println("Record inserted successfully");
            } while (want.equals("y"));

        } catch (HibernateException e) {
            System.out.println(e);
        } finally {
            ss.close();
        }
    }

    public void DisplayOrganisationRecords() {
        ss = sf.openSession();
        try {

            ss.beginTransaction();
            List<Organisation> e1 = ss.createQuery("from Organisation").getResultList();

            for (Iterator iterator = e1.iterator(); iterator.hasNext();) {
                Organisation org1 = (Organisation) iterator.next();
                System.out.println(org1.getname() + "  "
                        + org1.getemail()
                        + "   " + org1.getId()
                        + "   " + org1.getpass());
            }
            ss.getTransaction().commit();

        } catch (HibernateException e) {

            System.out.println(e);

        } finally {

            ss.close();

        }
    }

    public void RemoveOrganisationRecord() {
        ss = sf.openSession();
        try {
            ss.beginTransaction();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter Organisation ID");
            Long id = sc.nextLong();

            Query query = ss.createQuery("from Organisation where id =" + id);
            Organisation org = (Organisation) query.uniqueResult();
            ss.delete(org);
            ss.getTransaction().commit();
            System.out.println("Removed Record successfully");
        } catch (HibernateException he) {
            he.printStackTrace();
        } finally {
            ss.close();
        }
    }

    public void UpdateOrganisationRecord() {
        ss = sf.openSession();
        try {
            ss.beginTransaction();
            Scanner sc = new Scanner(System.in);
            System.out.println("Enter Organisation ID");
            Long id = sc.nextLong();
            System.out.println("Update your name");
            String name = sc.next();
            System.out.println("Update your email");
            String email = sc.next();
            System.out.println("Update your password");
            String pass = sc.next();


            Query query = ss.createQuery("from Organisation where id =" + id);
            Organisation org = (Organisation) query.uniqueResult();
            org.SetEmail(email);
            org.SetName(name);
            org.SetName(pass);
            ss.update(org);
            ss.getTransaction().commit();
            System.out.println("Record is updated");
        } catch (HibernateException he) {
            he.printStackTrace();
        } finally {
            ss.close();
        }
    }

    public static void OrganisationMenu() {
        Test t2 = new Test();

        Configuration configuration = new Configuration();
        ssr = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
        configuration.addAnnotatedClass(Organisation.class).addAnnotatedClass(Employee.class);

        sf = configuration.buildSessionFactory(ssr);

        try {
            int Input;
            do {
                Scanner sc = new Scanner(System.in);
                System.out.println("========Organisation Menu========");
                System.out.println("1.Create a record");
                System.out.println("2.Display a record");
                System.out.println("3.Update record");
                System.out.println("4.Remove a record");
                System.out.println("5.Exit ");
                System.out.println("6.Press 0 for back");
                System.out.println("Enter your choice  :");
                Input = sc.nextInt();


                switch (Input) {
                    case 1:
                        t2.SaveOrganisationRecords();
                        break;
                    case 2:
                        t2.DisplayOrganisationRecords();
                        break;
                    case 3:
                        t2.UpdateOrganisationRecord();
                        break;
                    case 4:
                        t2.RemoveOrganisationRecord();
                        break;
                    case 5:
                        System.exit(1);
                    default:
                        System.out.println("Wrong Input");

                }

            }
            while (Input != 0);

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
public static void login() {
    Configuration configuration = new Configuration();
    ssr = new StandardServiceRegistryBuilder().applySettings(configuration.getProperties()).build();
    configuration.addAnnotatedClass(Organisation.class).addAnnotatedClass(Employee.class);;
    sf = configuration.buildSessionFactory(ssr);

    ss = sf.openSession();
    try {
        int n = 0;
    do {
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter your Organisation ID");
        Long id = sc.nextLong();
        System.out.println("Enter your password");
        String pass = sc.next();
        List<Organisation> e1 = ss.createQuery("from Organisation").getResultList();


        for (Iterator iterator = e1.iterator(); iterator.hasNext();) {
            Organisation org = (Organisation) iterator.next();
            String check = org.getpass();
            Long Check1 = org.getId();

            if ((pass.equals(check)) && (id == Check1)) {
                System.out.println("Login successfully");
                EmployeeMenu(id);
                n++;
            }
            }
            if( n== 0) {
                System.out.println("password is incorrect");
            }
    } while (n == 0);
}
 catch(HibernateException e)

    {
        e.printStackTrace();
    }


        finally {
            ss.close();
    }
}

    public static void main(String[] args) {
        try {


            int Input;
            do {
                Scanner sc = new Scanner(System.in);
                System.out.println("=======Main Menu========");
                System.out.println("1.For Organisation ");
                System.out.println("2.For Employee");
                System.out.println("3.Exit");
                System.out.println("Enter your choice  :");
                Input = sc.nextInt();


                switch (Input) {
                    case 1:
                        OrganisationMenu();
                        break;
                    case 2:
                        login();
                        break;
                    case 3:
                        System.exit(1);
                    default:
                        System.out.println("Wrong Input");

                }

            } while (Input != 0);
        }
        catch (Exception e) {
            e.printStackTrace();
        }


    }
}
