package com.entity;

import com.entitiees.Employee;

import javax.persistence.*;
import java.util.List;

@Entity
public class Organisation {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long oid;
    private String oname;
    private String email;
    private String pass;

    public List<Employee> getEmployee() {
        return employee;
    }

    public void setEmployee(List<Employee> employee) {
        this.employee = employee;
    }

    @OneToMany(cascade = CascadeType.MERGE, fetch = FetchType.EAGER)
    private List<Employee> employee;
    public Organisation() {
    }


    public String getname() {
        return oname;
    }

    public Long getId() {
        return oid;
    }

    public String getemail() {
        return email;
    }

    public String getpass() {
        return pass;
    }

    public void SetId(Long oid) {
        this.oid = oid;
    }

    public void SetName(String oname){
        this.oname=oname;
    }
    public void SetEmail(String email) {
        this.email = email;
    }
    public void SetPass(String pass) {
        this.pass=pass;
    }



}
