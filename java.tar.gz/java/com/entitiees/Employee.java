package com.entitiees;

import com.entity.Organisation;

import javax.persistence.*;

@Entity
public class Employee {
    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    private Long id;
    private String name;
    private int sal;
    @ManyToOne(cascade=CascadeType.MERGE, fetch = FetchType.LAZY)
    private Organisation organisation;

    public Organisation getOrganisation() {
        return organisation;
    }

    public void setOrganisation(Organisation organisation) {
        this.organisation = organisation;
    }

    public String getname() {
        return name;
    }
    public int getsal() {
        return sal;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public void SetName(String name){
        this.name=name;
    }
    public void SetSal(int sal) {
        this.sal = sal;
    }


}


